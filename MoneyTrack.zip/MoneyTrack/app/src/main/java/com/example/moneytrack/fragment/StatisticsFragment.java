package com.example.moneytrack.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moneytrack.R;
import com.example.moneytrack.adapter.CategorySummaryAdapter;
import com.example.moneytrack.database.DatabaseHelper;
import com.example.moneytrack.model.CategorySummary;
import com.example.moneytrack.utils.CurrencyUtils;
import com.example.moneytrack.view.SimpleBarChartView;

import java.util.List;

/**
 * Halaman Statistik: total, selisih saldo, grafik, dan pengeluaran per kategori.
 */
public class StatisticsFragment extends Fragment {

    private TextView tvStatIncome;
    private TextView tvStatExpense;
    private TextView tvStatBalance;
    private TextView tvEmptyCategory;
    private SimpleBarChartView chartStatistics;
    private RecyclerView rvCategory;
    private CategorySummaryAdapter adapter;
    private DatabaseHelper db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_statistics, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = DatabaseHelper.getInstance(requireContext());

        tvStatIncome = view.findViewById(R.id.tvStatIncome);
        tvStatExpense = view.findViewById(R.id.tvStatExpense);
        tvStatBalance = view.findViewById(R.id.tvStatBalance);
        tvEmptyCategory = view.findViewById(R.id.tvEmptyCategory);
        chartStatistics = view.findViewById(R.id.chartStatistics);
        rvCategory = view.findViewById(R.id.rvCategory);

        adapter = new CategorySummaryAdapter(requireContext());
        rvCategory.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvCategory.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        long income = db.getTotalIncome();
        long expense = db.getTotalExpense();
        long balance = income - expense;

        tvStatIncome.setText(CurrencyUtils.format(income));
        tvStatExpense.setText(CurrencyUtils.format(expense));
        tvStatBalance.setText(CurrencyUtils.format(balance));
        tvStatBalance.setTextColor(ContextCompat.getColor(requireContext(),
                balance >= 0 ? R.color.income : R.color.expense));
        chartStatistics.setData(income, expense);

        List<CategorySummary> summaries = db.getExpenseSummaryByCategory();
        adapter.setItems(summaries, expense);
        boolean empty = summaries.isEmpty();
        tvEmptyCategory.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvCategory.setVisibility(empty ? View.GONE : View.VISIBLE);
    }
}
