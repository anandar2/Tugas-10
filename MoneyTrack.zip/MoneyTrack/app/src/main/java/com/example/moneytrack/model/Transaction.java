package com.example.moneytrack.model;

/**
 * Model data untuk satu transaksi keuangan.
 * Nominal disimpan sebagai long (Rupiah tidak memakai desimal)
 * agar tidak ada kesalahan pembulatan seperti pada double.
 */
public class Transaction {

    public static final String TYPE_INCOME = "INCOME";
    public static final String TYPE_EXPENSE = "EXPENSE";

    private long id;
    private String type;
    private long amount;
    private String category;
    private String description;
    private String date; // format yyyy-MM-dd

    public Transaction() {
    }

    public Transaction(String type, long amount, String category, String description, String date) {
        this.type = type;
        this.amount = amount;
        this.category = category;
        this.description = description;
        this.date = date;
    }

    public Transaction(long id, String type, long amount, String category, String description, String date) {
        this(type, amount, category, description, date);
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isIncome() {
        return TYPE_INCOME.equals(type);
    }
}
