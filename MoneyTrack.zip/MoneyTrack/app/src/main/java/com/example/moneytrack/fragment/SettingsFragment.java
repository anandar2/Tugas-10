package com.example.moneytrack.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import com.example.moneytrack.R;
import com.example.moneytrack.utils.PrefsManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Halaman Pengaturan: semua nilai dibaca/ditulis lewat PrefsManager (SharedPreferences).
 */
public class SettingsFragment extends Fragment {

    private TextInputLayout tilUserName;
    private TextInputEditText etUserName;
    private SwitchMaterial switchDarkMode;
    private SwitchMaterial switchNotification;
    private AutoCompleteTextView actvCurrency;
    private MaterialButton btnSaveSettings;
    private PrefsManager prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        prefs = new PrefsManager(requireContext());

        tilUserName = view.findViewById(R.id.tilUserName);
        etUserName = view.findViewById(R.id.etUserName);
        switchDarkMode = view.findViewById(R.id.switchDarkMode);
        switchNotification = view.findViewById(R.id.switchNotification);
        actvCurrency = view.findViewById(R.id.actvCurrency);
        btnSaveSettings = view.findViewById(R.id.btnSaveSettings);

        String[] currencies = getResources().getStringArray(R.array.currency_options);
        actvCurrency.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, currencies));

        btnSaveSettings.setOnClickListener(v -> saveSettings());
    }

    @Override
    public void onResume() {
        super.onResume();
        // Baca ulang nilai tersimpan dari SharedPreferences setiap halaman tampil
        loadSettings();
    }

    private void loadSettings() {
        etUserName.setText(prefs.getUserName());
        switchDarkMode.setChecked(prefs.getThemeMode() == AppCompatDelegate.MODE_NIGHT_YES);
        switchNotification.setChecked(prefs.isNotificationEnabled());
        actvCurrency.setText(getResources().getStringArray(R.array.currency_options)[0], false);
    }

    private void saveSettings() {
        String name = etUserName.getText() == null ? "" : etUserName.getText().toString().trim();
        if (name.isEmpty()) {
            tilUserName.setError(getString(R.string.error_name));
            return;
        }
        tilUserName.setError(null);

        int themeMode = switchDarkMode.isChecked()
                ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO;

        // Simpan ke SharedPreferences (memakai editor.apply())
        prefs.saveSettings(name, themeMode, PrefsManager.DEFAULT_CURRENCY,
                switchNotification.isChecked());

        Toast.makeText(requireContext(), R.string.msg_settings_saved, Toast.LENGTH_SHORT).show();

        // Terapkan tema; jika mode berubah, Activity otomatis dibuat ulang
        prefs.applyTheme();
    }
}
