package com.example.moneytrack.utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Format nominal ke Rupiah, contoh: 1500000 -> "Rp 1.500.000".
 */
public class CurrencyUtils {

    private CurrencyUtils() {
    }

    private static DecimalFormat createFormat() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("id", "ID"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        return new DecimalFormat("#,##0", symbols);
    }

    public static String format(long amount) {
        String number = createFormat().format(Math.abs(amount));
        return (amount < 0 ? "-Rp " : "Rp ") + number;
    }

    /** Format dengan tanda: "+ Rp 1.000" untuk pemasukan, "- Rp 1.000" untuk pengeluaran. */
    public static String formatSigned(long amount, boolean income) {
        return (income ? "+ " : "- ") + format(amount);
    }
}
