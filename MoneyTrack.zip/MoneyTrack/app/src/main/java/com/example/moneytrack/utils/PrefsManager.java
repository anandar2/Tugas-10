package com.example.moneytrack.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * PrefsManager: satu-satunya class yang mengakses SharedPreferences.
 *
 * Data yang disimpan (BUKAN daftar transaksi):
 * - nama pengguna
 * - tema (Dark Mode / Light Mode)
 * - mata uang
 * - pengaturan notifikasi
 *
 * Semua penulisan memakai editor.apply() sehingga disimpan secara
 * asynchronous ke file XML di penyimpanan internal aplikasi dan tetap ada
 * setelah aplikasi ditutup maupun di-Force Stop.
 */
public class PrefsManager {

    // Nama file preferensi: /data/data/com.example.moneytrack/shared_prefs/moneytrack_prefs.xml
    public static final String PREF_NAME = "moneytrack_prefs";

    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_THEME_MODE = "theme_mode";
    private static final String KEY_CURRENCY = "currency";
    private static final String KEY_NOTIFICATION = "notification_enabled";

    public static final String DEFAULT_USER_NAME = "Pengguna";
    public static final String DEFAULT_CURRENCY = "IDR";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        // applicationContext dipakai agar tidak menahan referensi Activity
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    // ---------------- Nama pengguna ----------------

    /** Menyimpan nama pengguna. */
    public void setUserName(String name) {
        prefs.edit().putString(KEY_USER_NAME, name).apply();
    }

    /** Membaca nama pengguna; jika belum pernah disimpan, mengembalikan "Pengguna". */
    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, DEFAULT_USER_NAME);
    }

    // ---------------- Tema ----------------

    /**
     * Menyimpan mode tema.
     * Nilai: AppCompatDelegate.MODE_NIGHT_YES (Dark) atau MODE_NIGHT_NO (Light).
     */
    public void setThemeMode(int mode) {
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply();
    }

    /** Membaca mode tema; default Light Mode. */
    public int getThemeMode() {
        return prefs.getInt(KEY_THEME_MODE, AppCompatDelegate.MODE_NIGHT_NO);
    }

    /** Menerapkan tema yang tersimpan ke seluruh aplikasi. */
    public void applyTheme() {
        AppCompatDelegate.setDefaultNightMode(getThemeMode());
    }

    // ---------------- Mata uang ----------------

    /** Menyimpan kode mata uang (contoh: "IDR"). */
    public void setCurrency(String currency) {
        prefs.edit().putString(KEY_CURRENCY, currency).apply();
    }

    /** Membaca kode mata uang; default "IDR". */
    public String getCurrency() {
        return prefs.getString(KEY_CURRENCY, DEFAULT_CURRENCY);
    }

    // ---------------- Notifikasi ----------------

    /** Menyimpan status notifikasi (aktif / nonaktif). */
    public void setNotificationEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_NOTIFICATION, enabled).apply();
    }

    /** Membaca status notifikasi; default aktif. */
    public boolean isNotificationEnabled() {
        return prefs.getBoolean(KEY_NOTIFICATION, true);
    }

    // ---------------- Simpan sekaligus ----------------

    /**
     * Menyimpan semua pengaturan dalam satu editor, lalu apply() sekali.
     * Lebih efisien dan atomik dibanding memanggil setter satu per satu.
     */
    public void saveSettings(String name, int themeMode, String currency, boolean notificationEnabled) {
        prefs.edit()
                .putString(KEY_USER_NAME, name)
                .putInt(KEY_THEME_MODE, themeMode)
                .putString(KEY_CURRENCY, currency)
                .putBoolean(KEY_NOTIFICATION, notificationEnabled)
                .apply();
    }
}
