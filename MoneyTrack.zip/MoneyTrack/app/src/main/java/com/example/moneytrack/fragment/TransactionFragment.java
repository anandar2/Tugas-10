package com.example.moneytrack.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moneytrack.AddTransactionActivity;
import com.example.moneytrack.R;
import com.example.moneytrack.adapter.TransactionAdapter;
import com.example.moneytrack.database.DatabaseHelper;
import com.example.moneytrack.model.Transaction;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

/**
 * Halaman Riwayat Transaksi: daftar, filter jenis, pencarian, edit, dan hapus.
 */
public class TransactionFragment extends Fragment implements TransactionAdapter.OnActionListener {

    private TextInputEditText etSearch;
    private ChipGroup chipGroup;
    private RecyclerView rvTransactions;
    private TextView tvEmpty;
    private TransactionAdapter adapter;
    private DatabaseHelper db;

    /** null = semua jenis */
    private String currentType = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_transaction, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = DatabaseHelper.getInstance(requireContext());

        etSearch = view.findViewById(R.id.etSearch);
        chipGroup = view.findViewById(R.id.chipGroup);
        rvTransactions = view.findViewById(R.id.rvTransactions);
        tvEmpty = view.findViewById(R.id.tvEmpty);
        FloatingActionButton fabAdd = view.findViewById(R.id.fabAdd);

        adapter = new TransactionAdapter(requireContext(), true, this);
        rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvTransactions.setAdapter(adapter);

        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) {
                currentType = null;
            } else {
                int id = checkedIds.get(0);
                if (id == R.id.chipIncome) {
                    currentType = Transaction.TYPE_INCOME;
                } else if (id == R.id.chipExpense) {
                    currentType = Transaction.TYPE_EXPENSE;
                } else {
                    currentType = null;
                }
            }
            loadData();
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                loadData();
            }
        });

        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AddTransactionActivity.class)));
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        String keyword = etSearch.getText() == null ? "" : etSearch.getText().toString();
        List<Transaction> list = db.searchTransactions(keyword, currentType);
        adapter.setItems(list);

        boolean empty = list.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvTransactions.setVisibility(empty ? View.GONE : View.VISIBLE);
        boolean filtering = !keyword.trim().isEmpty() || currentType != null;
        tvEmpty.setText(filtering ? R.string.empty_search : R.string.empty_transactions);
    }

    @Override
    public void onEdit(Transaction transaction) {
        Intent intent = new Intent(requireContext(), AddTransactionActivity.class);
        intent.putExtra(AddTransactionActivity.EXTRA_TRANSACTION_ID, transaction.getId());
        startActivity(intent);
    }

    @Override
    public void onDelete(Transaction transaction) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.dialog_delete_title)
                .setMessage(getString(R.string.dialog_delete_message, transaction.getDescription()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    db.deleteTransaction(transaction.getId());
                    Toast.makeText(requireContext(), R.string.msg_deleted, Toast.LENGTH_SHORT).show();
                    loadData();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
