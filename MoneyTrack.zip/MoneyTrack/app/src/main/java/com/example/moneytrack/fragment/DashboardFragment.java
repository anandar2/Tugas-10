package com.example.moneytrack.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moneytrack.AddTransactionActivity;
import com.example.moneytrack.R;
import com.example.moneytrack.adapter.TransactionAdapter;
import com.example.moneytrack.database.DatabaseHelper;
import com.example.moneytrack.model.Transaction;
import com.example.moneytrack.utils.CurrencyUtils;
import com.example.moneytrack.utils.PrefsManager;
import com.example.moneytrack.view.SimpleBarChartView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.List;

/**
 * Halaman Dashboard: sapaan, saldo, total masuk/keluar, grafik, dan transaksi terbaru.
 */
public class DashboardFragment extends Fragment {

    private TextView tvGreeting;
    private TextView tvBalance;
    private TextView tvIncome;
    private TextView tvExpense;
    private TextView tvEmpty;
    private SimpleBarChartView chartSummary;
    private RecyclerView rvRecent;
    private TransactionAdapter adapter;

    private DatabaseHelper db;
    private PrefsManager prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = DatabaseHelper.getInstance(requireContext());
        prefs = new PrefsManager(requireContext());

        tvGreeting = view.findViewById(R.id.tvGreeting);
        tvBalance = view.findViewById(R.id.tvBalance);
        tvIncome = view.findViewById(R.id.tvIncome);
        tvExpense = view.findViewById(R.id.tvExpense);
        tvEmpty = view.findViewById(R.id.tvEmpty);
        chartSummary = view.findViewById(R.id.chartSummary);
        rvRecent = view.findViewById(R.id.rvRecent);
        FloatingActionButton fabAdd = view.findViewById(R.id.fabAdd);

        adapter = new TransactionAdapter(requireContext(), false, null);
        rvRecent.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvRecent.setAdapter(adapter);

        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AddTransactionActivity.class)));
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        // Pengaturan dari SharedPreferences
        tvGreeting.setText(getGreeting() + ", " + prefs.getUserName() + "!");

        // Data dari SQLite
        long income = db.getTotalIncome();
        long expense = db.getTotalExpense();
        tvBalance.setText(CurrencyUtils.format(income - expense));
        tvIncome.setText(CurrencyUtils.format(income));
        tvExpense.setText(CurrencyUtils.format(expense));
        chartSummary.setData(income, expense);

        List<Transaction> recent = db.getRecentTransactions(5);
        adapter.setItems(recent);
        boolean empty = recent.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        rvRecent.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private String getGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 11) {
            return "Selamat pagi";
        } else if (hour < 15) {
            return "Selamat siang";
        } else if (hour < 18) {
            return "Selamat sore";
        }
        return "Selamat malam";
    }
}
